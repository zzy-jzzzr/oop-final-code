import javax.swing.*;
import java.awt.*;
import java.awt.List;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import java.util.*;

public class ChatRoom extends Thread implements ActionListener {
    static JFrame java_Chat;       // ´´½¨Ò»¸öÐÂµÄjava´°¿Ú
    JPanel Chat_pnl;     // ´´½¨Ò»¸öÃæ°å×é¼þ
    JButton delChat;    // ´´½¨¡°Çå³ýÁÄÌì¼ÇÂ¼¡±°´Å¥
    JButton exiChat;    // ´´½¨¡°ÍË³ö¡±°´Å¥
    JButton sendChat;   // ´´½¨¡°·¢ËÍ¡±°´Å¥
    JButton saveChat;   // ´´½¨¡°±£´æÁÄÌì¼ÇÂ¼¡±°´Å¥
    TextArea inputBox;    // ´´½¨ÁÄÌìÐÅÏ¢ÊäÈë¿ò
    TextArea ChatRecord;   // ´´½¨ÁÄÌì¼ÇÂ¼ÏÔÊ¾½çÃæ
    java.awt.List UserList;     // ´´½¨ÓÃ»§ÁÐ±í
    JCheckBox isPriChat;   // ÉèÖÃÊÇ·ñÑ¡ÔñË½ÁÄ
    JComboBox selChatObj;   // Ñ¡ÔñÁÄÌì¶ÔÏó
    final JLabel labHead = new JLabel();      // ´´½¨ÁÄÌì¿òµÄÍ·±êÇ©
    // ´´½¨Ò»Ð©±êÇ©
    JLabel labOnUserList, labChatBox, labChatMessage, labUserNum, labCount;
    Dimension windowPos;    // ¹Ì¶¨´°¿ÚµÄ´ò¿ªÎ»ÖÃ
    Toolkit toolkit = Toolkit.getDefaultToolkit();
    Notice messobj = null;
    String serverMessage = "";
    String strServerIp, strLoginName;
    Thread thread;

    // ÖØ¹¹¼àÌý°´Å¥µÄÏìÓ¦
    @Override
    public void actionPerformed(ActionEvent e) 
    {
        Object source = e.getSource();
        // Çå³ýÁÄÌì¼ÇÂ¼°´Å¥ÏàÓ¦
        if (source.equals(delChat)) {
            clearMessage();
        }
        // ÍË³ö°´Å¥ÏìÓ¦
        else if (source.equals(exiChat)) {
            exit();
        }
        // ·¢ËÍ°´Å¥ÏìÓ¦
        else if (source.equals(sendChat)) {
            sendMessage();
        }
        // ±£´æÁÄÌì¼ÇÂ¼°´Å¥ÏìÓ¦
        else if (source.equals(saveChat)) {
            saveMessage();
        }
        // ÇÐ»»ÓÃ»§²Ù×÷ÏìÓ¦
        else if (source.equals(UserList)) // Ë«»÷ÁÐ±í¿ò
        {
            changeUser();
        }
    }

    // ¼àÌý´°¿Ú¹Ø±ÕÏìÓ¦
    class Windowclose extends WindowAdapter
    {
        public void windowClosing(WindowEvent e)
        {
            exit();
        }
    }

    // ÁÄÌìÊÒ¹¹Ôì
    public ChatRoom(String name, String ip) {
        strServerIp = ip;
        strLoginName = name;
        java_Chat = new JFrame("国服JAVA聊天室" + "当前英雄：" + name);
        java_Chat.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   // ÉèÖÃ´°¿Ú¹Ø±ÕÑ¡Ïî
        java_Chat.setSize(800, 650);        // ÉèÖÃÕû¸ö´°¿ÚµÄÏà¹Ø´óÐ¡
        java_Chat.setVisible(true);     // ÉèÖÃ´°¿ÚÊÇ¿É¼ûµÄ
        java_Chat.setResizable(false); // ÉèÖÃ´°¿Ú²»¿ÉÒÔµ÷Õû´óÐ¡

        Chat_pnl = new JPanel();        // Ãæ°å×é¼þ³õÊ¼»¯
        java_Chat.getContentPane().add(Chat_pnl);       // ÔÚ´°¿ÚÖÐ¼ÓÈëÃæ°å×é¼þ
        Chat_pnl.setLayout(null);       // ÉèÖÃÃæ°å²¼¾ÖÎªnull
        Chat_pnl.setBackground(new Color(176, 196, 222));    // ÉèÖÃÃæ°å±³¾°ÑÕÉ«

        String[] List = {"所有人"};
        // ÊµÀý»¯¸÷°´Å¥
        delChat = new JButton("清除聊天记录");
        exiChat = new JButton("退出");
        sendChat = new JButton("发送");
        saveChat = new JButton("保存聊天记录");
        // 实例化信息输入框
        inputBox = new TextArea("",300,170,TextArea.SCROLLBARS_VERTICAL_ONLY);
        ChatRecord = new TextArea("", 300, 200, TextArea.SCROLLBARS_VERTICAL_ONLY);
        UserList = new java.awt.List();
        isPriChat = new JCheckBox("私密消息");
        selChatObj = new JComboBox(List);
        // 实例化各标签
        labOnUserList = new JLabel("在线用户列表");
        labChatBox = new JLabel("聊天框");
        labUserNum = new JLabel("/在线人数：");
        labChatMessage = new JLabel("聊天内容输入:");
        labCount = new JLabel("0");
        // ½«°´Å¥¼ÓÈëÃæ°å
        Chat_pnl.add(delChat);
        Chat_pnl.add(exiChat);
        Chat_pnl.add(sendChat);
        Chat_pnl.add(saveChat);
        Chat_pnl.add(inputBox);
        Chat_pnl.add(ChatRecord);
        Chat_pnl.add(UserList);
        Chat_pnl.add(isPriChat);
        Chat_pnl.add(selChatObj);
        Chat_pnl.add(labHead);
        Chat_pnl.add(labOnUserList);
        Chat_pnl.add(labChatBox);
        Chat_pnl.add(labChatMessage);
        Chat_pnl.add(labUserNum);
        Chat_pnl.add(labCount);
        // ÉèÖÃ°´Å¥µÄ¸ñÊ½
        // ÉèÖÃ°´Å¥µÄÒ³Ãæ²¼¾Ö
        delChat.setBounds(235, 505, 120, 25);
        exiChat.setBounds(235, 540, 120, 25);
        sendChat.setBounds(650, 560, 120, 25);
        saveChat.setBounds(235, 470, 120, 25);
        inputBox.setBounds(380, 430, 395, 125);      // ÉèÖÃÏûÏ¢ÊäÈë¿òµÄÒ³Ãæ²¼¾Ö
        ChatRecord.setBounds(225, 60, 550, 330);    // ÉèÖÃÁÄÌìÏÔÊ¾¿òµÄÒ³Ãæ²¼¾Ö
        UserList.setBounds(5, 75, 210, 515);        // ÉèÖÃÓÃ»§ÁÐ±íµÄÒ³Ãæ²¼¾Ö
        isPriChat.setBounds(235, 400, 120, 25);     // ÉèÖÃË½ÁÄ¸´Ñ¡¿òµÄÒ³Ãæ²¼¾Ö
        selChatObj.setBounds(235, 435, 120, 25);      // ÉèÖÃÏÂÀ­¸´Ñ¡¿òµÄÒ³Ãæ²¼¾Ö
        labHead.setBounds(10, 5, 70, 50);         // ÉèÖÃÍ·±êÇ©µÄÒ³Ãæ²¼¾Ö
        labOnUserList.setBounds(5, 50, 120, 25);
        labChatBox.setBounds(227, 30, 180, 30);
        labChatMessage.setBounds(380, 400, 120, 25);
        labUserNum.setBounds(90, 50, 90, 25);
        labCount.setBounds(165, 50, 60, 25);
        // ÉèÖÃ°´Å¥×ÖÌå
        delChat.setFont(new Font("黑体", Font.PLAIN, 14));
        exiChat.setFont(new Font("黑体", Font.PLAIN, 14));
        sendChat.setFont(new Font("黑体", Font.PLAIN, 14));
        saveChat.setFont(new Font("黑体", Font.PLAIN, 14));
        inputBox.setFont(new Font("黑体", Font.PLAIN, 14));
        inputBox.setForeground(Color.black);
        inputBox.setBackground(new Color(255, 239, 219));
        ChatRecord.setBackground(new Color(255, 239, 219));
        ChatRecord.setEditable(false);
        UserList.setFont(new Font("黑体", Font.PLAIN, 17));
        UserList.setBackground(new Color(255, 239, 219));
        isPriChat.setFont(new Font("黑体", Font.PLAIN, 14));
        selChatObj.setFont(new Font("黑体", Font.PLAIN, 14));
        isPriChat.setForeground(Color.black);
        selChatObj.setForeground(Color.black);
        labOnUserList.setFont(new Font("黑体", Font.BOLD, 14));
        labOnUserList.setForeground(Color.black);
        labChatBox.setFont(new Font("黑体", Font.PLAIN, 16));
        labChatBox.setForeground(Color.BLACK);
        labChatMessage.setFont(new Font("黑体", Font.PLAIN, 14));
        labChatMessage.setForeground(Color.black);
        labUserNum.setFont(new Font("黑体", Font.BOLD, 14));
        labUserNum.setForeground(Color.black);
        labCount.setFont(new Font("黑体", Font.BOLD, 14));
        labCount.setForeground(Color.black);
        // ÉèÖÃ°´Å¥±³¾°
        delChat.setBackground(Color.pink);
        exiChat.setBackground(Color.pink);
        sendChat.setBackground(Color.pink);
        saveChat.setBackground(Color.pink);
        // Ìí¼Óµã»÷ÊÂ¼þ
        java_Chat.addWindowListener(new Windowclose());
        delChat.addActionListener(this);
        exiChat.addActionListener(this);
        sendChat.addActionListener(this);
        saveChat.addActionListener(this);
        UserList.addActionListener(this);
        // ÉèÖÃTextAreaµÄ¸ñÊ½
        ChatRecord.setForeground(new Color(0, 0, 0));
        ChatRecord.setEditable(false); // ²»¿ÉÐ´Èë
        selChatObj.addItemListener(new ItemListener() {     // Ìí¼ÓÑ¡ÏîÑ¡ÖÐ×´Ì¬¸Ä±äµÄ¼àÌýÆ÷
            @Override
            public void itemStateChanged(ItemEvent mei) {
                freshHead();
            }
        });
        // ÉèÖÃÍ·±êÇ©µÄ¸ñÊ½
        labHead.setHorizontalAlignment(SwingConstants.CENTER);
        labHead.setIcon(new ImageIcon("headpics/1.JPG"));
        // ¹Ì¶¨´°¿Ú´ò¿ªÊ±ÔÚÆÁÄ»ÖÐ¼ä
        windowPos = toolkit.getScreenSize();
        java_Chat.setLocation(windowPos.width / 2 - java_Chat.getWidth() / 2,
                (int) (windowPos.height / 2 - windowPos.getHeight() / 2));
        // ÊµÀý»¯Ïß³Ì¡¢Æô¶¯Ïß³Ì
        thread = new Thread(this);
        thread.start();

        Image img = toolkit.getImage("images\\appico.jpg");
        java_Chat.setIconImage(img);
    }

    // Çå³ýÁÄÌì¼ÇÂ¼·½·¨
    public void clearMessage() {
        ChatRecord.setText("");
    }

    // ÍË³öÁÄÌì¿ò·½·¨
    public void exit() 
    {
        User exit = new User();
        exit.name = strLoginName;
        exit.isOnQuit = true;
        exit.isOnReg = false;
        exit.isOnLogin = false;
        // ·¢ËÍÍË³öÐÅÏ¢
        try {
            Socket toServer = new Socket(strServerIp, 1921);
            // Ïò·þÎñÆ÷·¢ËÍÐÅÏ¢
            ObjectOutputStream outObj = new ObjectOutputStream(toServer.getOutputStream());
            outObj.writeObject(exit);
            outObj.close();
            toServer.close();

            java_Chat.dispose();
        } 
        catch (Exception e)
        {
        	e.printStackTrace();
        }
    }

    // ·¢ËÍÁÄÌì¼ÇÂ¼·½·¨
    public void sendMessage() 
    {
        Record chatobj = new Record();
        chatobj.sender = strLoginName;
        chatobj.chatComp = inputBox.getText();
        chatobj.receiver = String.valueOf(selChatObj.getSelectedItem());
        chatobj.isPrivate = isPriChat.isSelected();
        try {
            Socket toServer = new Socket(strServerIp, 1921);
            ObjectOutputStream outObj = new ObjectOutputStream(toServer.getOutputStream());
            outObj.writeObject(chatobj);
            inputBox.setText("");
            outObj.close();
            toServer.close();
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        }
    }

    // ±£´æÁÄÌì¼ÇÂ¼·½·¨
    public void saveMessage() {
        try {
            FileOutputStream fileoutput = new FileOutputStream(this.strLoginName + "_message.txt", true);
            String temp = ChatRecord.getText();
            fileoutput.write(temp.getBytes());
            fileoutput.close();
            JOptionPane.showMessageDialog(null, "聊天记录保存在" + this.strLoginName + "_message.txt");
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    // ¸ü»»µ±Ç°ÓÃ»§
    public void changeUser()
    {
        boolean key = true;
        String selected = UserList.getSelectedItem();
        for (int i = 0; i < selChatObj.getItemCount(); i++) 
        {
            if (selected.equals(selChatObj.getItemAt(i)))
            {
                key = false;
                break;
            }
        }
        if (key)
        {
            selChatObj.insertItemAt(selected, 0);
        }
        String head = getUserHead(UserList.getSelectedItem());
        selChatObj.setSelectedItem(selected);

        labHead.setIcon(new ImageIcon("face//" + head + ".JPG"));
    }

    // »ñÈ¡Ä³ÓÃ»§µÄÍ·ÏñÍ¼Æ¬Ãû
    private String getUserHead(String selectedItem) {
        String head = null;
        for (Object a : messobj.userOnline) {
            String User = ((User) a).name;
            head = ((User) a).headpic;
            if (User.equals(selectedItem)) {
                break;
            }
        }
        return head;
    }

    protected void freshHead() {
        String head = getUserHead(selChatObj.getSelectedItem().toString());
        labHead.setIcon(new ImageIcon("face//" + head + ".JPG"));
    }

    // Ïß³ÌµÄrun()º¯Êý
    @SuppressWarnings("deprecation")
    public void run() {
        int intMessageCounter = 0;        // ÏûÏ¢×ÜÊý
        int intUserTotal = 0;
        boolean isFirstLogin = true; // ÅÐ¶ÏÊÇ·ñ¸ÕµÇÂ½
        boolean isFound; // ÅÐ¶ÏÊÇ·ñÕÒµ½ÓÃ»§
        ArrayList<User> user_exit = new ArrayList<User>();

        try {
            for(;;) {
                // IPµØÖ·ºÍ¶Ë¿Ú£¨Ð´ËÀ/²»¿É¸ü¸Ä£©
                Socket toServer = new Socket(strServerIp, 1921);
                // ½«ÐÅÏ¢·¢Íù·þÎñÆ÷
                messobj = new Notice();
                ObjectOutputStream streamToServer = new ObjectOutputStream(toServer.getOutputStream());
                streamToServer.writeObject(messobj);
                // ÊÕÀ´×Ô·þÎñÆ÷µÄÐÅÏ¢
                ObjectInputStream streamFromServer = new ObjectInputStream(toServer.getInputStream());
                messobj = (Notice) streamFromServer.readObject();

                if (isFirstLogin) // Èç¹û¸ÕµÇÂ½
                {
                    intMessageCounter = messobj.records.size(); // ÆÁ±Î¸ÃÓÃ»§µÇÂ½Ç°µÄÁÄÌìÄÚÈÝ
                    isFirstLogin = false;
                }
                if (!serverMessage.equals(messobj.notice)) {
                    // ½«ÁÄÌì¼ÇÂ¼Í¬²½µ½ÎÄ±¾¿òÀïÃæ
                    serverMessage = messobj.notice;
                    ChatRecord.append("[系统消息]：" + serverMessage + "\n");
                }
                for (int i = intMessageCounter; i < messobj.records.size(); i++) {
                    Record temp = (Record) messobj.records.get(i);
                    String temp_message;
                    if (temp.sender.equals(strLoginName)) {
                        if (temp.receiver.equals(strLoginName)) {
                            temp_message = "[系统提示：发送消息失败！请不要自言自语！]" + "\n";
                        } else {
                            if (!temp.isPrivate) // ²»ÊÇÇÄÇÄ»°
                            {
                                temp_message = "[你] 对 [" + temp.receiver + "] "
                                        + "说" + temp.chatComp
                                        + "\n";
                            } else {
                                temp_message = "[你] 悄悄对 [" + temp.receiver
                                        + "] " + "说" + temp.chatComp
                                        + "\n";
                            }
                        }
                    } else {
                        if (temp.receiver.equals(strLoginName)) {
                            if (!temp.isPrivate) // ²»ÊÇÇÄÇÄ»°
                            {
                                temp_message = "[" + temp.sender + "] 对 [你] "
                                        + "说" + temp.chatComp
                                        + "\n";
                            } else {
                                temp_message = "[" + temp.sender + "] 悄悄对 [你] "
                                        + "说" + temp.chatComp
                                        + "\n";
                            }
                        } else {
                            if (!temp.sender.equals(temp.receiver)) // ¶Ô·½Ã»ÓÐ×ÔÑÔ×ÔÓï
                            {
                                if (!temp.isPrivate) // ²»ÊÇÇÄÇÄ»°
                                {
                                    temp_message = "[" + temp.sender + "] 对 ["
                                            + temp.receiver + "] "
                                            + "说" + temp.chatComp + "\n";
                                } else {
                                    temp_message = "";
                                }
                            } else {
                                temp_message = "";
                            }
                        }
                    }
                    ChatRecord.append(temp_message);
                    intMessageCounter++;
                }

                // Ë¢ÐÂÔÚÏßÓÃ»§ÁÐ±í
                UserList.removeAll();
                for (int i = 0; i < messobj.userOnline.size(); i++) {
                    String User = ((User) messobj.userOnline.get(i)).name;
                    UserList.add(User);
                }
                int a = messobj.userOnline.size();
                labCount.setText(Integer.toString(a));
                // ÏÔÊ¾ÓÃ»§½øÈëÁÄÌìÊÒµÄÐÅÏ¢
                if (messobj.userOnline.size() > intUserTotal) {
                    String tempstr = ((User) messobj.userOnline
                            .get(messobj.userOnline.size() - 1)).name;
                    if (!tempstr.equals(strLoginName)) {
                        ChatRecord.append("[" + tempstr + "] 上线了" + "\n");
                    }
                }
                if (messobj.userOnline.size() < intUserTotal) {
                    for (int b = 0; b < user_exit.size(); b++) {
                        isFound = false;
                        for (int c = 0; c < messobj.userOnline.size(); c++) {
                            String tempstr = ((User) user_exit.get(b)).name;

                            if (tempstr.equals(((User) messobj.userOnline.get(c)).name)) {
                                isFound = true;
                                break;
                            }
                        }
                        if (!isFound) // Ã»ÓÐ·¢ÏÖ¸ÃÓÃ»§
                        {
                            String tempStr = ((User) user_exit.get(b)).name;

                            if (!tempStr.equals(strLoginName)) {
                                ChatRecord.append("[" + tempStr + "下线了"
                                        + "\n");
                            }
                        }
                    }
                }
                user_exit = messobj.userOnline;
                intUserTotal = messobj.userOnline.size();
                streamToServer.close();
                streamFromServer.close();
                toServer.close();
                Thread.sleep(3000);
            }

        } 
        catch (Exception e)
        {
            @SuppressWarnings("unused")
            JOptionPane jop = new JOptionPane();
            JOptionPane.showMessageDialog(null, "不能连接服务器！");
            e.printStackTrace();
            java_Chat.dispose();
        }
    }

    public static void main(String args[]) 
    {
        //new ChatRoom("²âÊÔÓÃ»§", "127.0.0.1");
    }
}
