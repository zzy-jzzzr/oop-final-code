import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server implements Runnable
{
	public static void main(String args[])
	{
		new Thread(new Server(), "用户线程启动").start();
	}
	//连接服务端和客户端
	ServerSocket serverForUser;
	//在线用户列表
	ArrayList<User> userOnline = new ArrayList<User>();
	
	//聊天记录列表
	ArrayList<Record> recordList = new ArrayList<Record>();
	//向服务器写入用户信息
	//ObjectInputStream inputStream;
	//向客户端写通知
	//PrintStream outputStream;
	//服务器窗口
	ServerWindow severwindow;
	
	@Override
	public void run()
	{
		try
		{
			while(true)
			{
				//持续监听客户端套接字
				Socket userSocket = serverForUser.accept();
				new Thread(new ServerThread(severwindow, userSocket, userOnline, recordList), "用户线程启动").start();
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
	}
	public Server(/*ServerWindow sw, Socket cs, ArrayList<User> ul, ArrayList<Record> rl*/)
	{
		try
		{
			serverForUser = new ServerSocket(1921);
			
			severwindow = new ServerWindow();
			//获取服务器名称
			severwindow.text_sName.setText(InetAddress.getLocalHost().getHostName());
			//获取IP地址
			severwindow.text_sIP.setText(InetAddress.getLocalHost().getHostAddress());
			//设置端口号
			severwindow.text_sPort.setText("1921");
			//设置服务器状态
			severwindow.text_sStatus.setText("服务器启动");
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
}
