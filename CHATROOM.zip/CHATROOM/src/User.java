
public class User extends Object implements java.io.Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String name;
	private String pwd;
	public String headpic;
	public String gender;
	public String age;
	public String email;
	public boolean isOnLogin;
	public boolean isOnReg;
	public boolean isOnQuit;
	public boolean isOnline = false;
	//public boolean isPatted = false;
	public String getPwd()
	{
		return pwd;
	}
	public void setPwd(String pwd)
	{
		this.pwd = pwd;
	}
	
}
