import java.io.Serializable;
import java.util.ArrayList;

public class Notice implements Serializable 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//在线人数，即通知发送对象
	public ArrayList<User> userOnline;
	//消息记录
	public ArrayList<Record> records;
	//通知
	public String notice;
	//public PatRecord pr;

}
