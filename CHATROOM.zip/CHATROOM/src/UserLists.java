import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class UserLists
{
	public static File userRegList = new File("user.txt");
	private static ArrayList<User> user_list = new ArrayList<User>();
	@SuppressWarnings({ "unchecked", "resource" })
	public static ArrayList<User> getul() throws FileNotFoundException, IOException, ClassNotFoundException
	{
		//ObjectInputStream objInput = new ObjectInputStream(new FileInputStream(userRegList));
		user_list = (ArrayList<User>) new ObjectInputStream(new FileInputStream(userRegList)).readObject();
		return user_list;
	}
	
}
