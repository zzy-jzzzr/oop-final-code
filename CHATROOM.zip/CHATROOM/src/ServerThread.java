import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class ServerThread implements Runnable
{
	//注册用户列表
	ArrayList<User> userReg;
	//向服务器写入用户信息
	ObjectInputStream inputStream;
	//向客户端写通知
	PrintStream outputStream;
	//服务窗口
	ServerWindow sw;
	//客户套接字
	Socket cs;
	//在线用户列表
	ArrayList<User> ul;
	//聊天信息列表
	ArrayList<Record> rl;
	//
	Object object;
	int maxNum = 80;
	@Override
	public void run()
	{
		try 
		{
			inputStream = new ObjectInputStream(this.cs.getInputStream());
			outputStream = new PrintStream(this.cs.getOutputStream());
			object =  inputStream.readObject();
			if(object.getClass().getName().equals("User"))
			{
				User user = (User) object;
				if(user.isOnLogin)
				{
					
					if(user.isOnline)
					{
						JOptionPane.showMessageDialog(null, "用户已登录", "错误提示",JOptionPane.ERROR_MESSAGE);
					}
					else
					{
						userLogin();
						user.isOnLogin = false;
						user.isOnline = true;
					}
					
				}
				else if(user.isOnReg)
				{
					userReg();
					user.isOnReg = false;
				}
				else if(user.isOnQuit)
				{
					int size = ul.size();
					for(int i = 0; i < size; i++)
					{
						if(ul.get(i).name.equals(user.name))
						{
							ul.remove(i);
							break;
						}
					}
					freshUL();
				}
			}
			else if(object.getClass().getName().equals("Record"))
			{
				sendChat();
			}
			else if(object.getClass().getName().equals("Notice"))
			{
				sendNotice();
			}
			else if(object.getClass().getName().equals("PatRecord"))
			{
				patpat();
			}
			else
			{
				System.out.println("Other");
			}
			
		} 
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@SuppressWarnings({ "unchecked" })
	public void userReg() throws FileNotFoundException, ClassNotFoundException, IOException
	{
		//userReg = UserList.getul();
		File userRegList = new File("user.txt");
		User user = (User) object;
		//int size = UserList.getul().size();
		int flag = 0;
		if(userRegList.length() != 0)
		{
			@SuppressWarnings("resource")
			ObjectInputStream objInput = new ObjectInputStream(new FileInputStream(userRegList));
			userReg = (ArrayList<User>) objInput.readObject();
			int size = userReg.size();
			for(int i = 0; i < size; i++)
			{
				if(userReg.get(i).name.equals(user.name) || userReg.get(i).name.equals("所有人"))
				{
					outputStream.println("用户名已存在");
					flag = 1;
					break;
				}
			}
			if(flag == 0)
			{
				//更新已注册用户
				userReg.add(user);
				//更新user.txt
				ObjectOutputStream temp = new ObjectOutputStream(new FileOutputStream(userRegList));
				temp.writeObject(userReg);
				outputStream.println("注册成功");
				temp.close();
				inputStream.close();
			}
		}
		else 
		{
			ObjectOutputStream temp = new ObjectOutputStream(new FileOutputStream(userRegList));
			if (userReg == null)
			{
				userReg = new ArrayList<>();
			}
			userReg.add(user);
			temp.writeObject(userReg);
			outputStream.println("注册成功");
			temp.close();
			inputStream.close();
		}
	}
	@SuppressWarnings("unchecked")
	public void userLogin() throws ClassNotFoundException
	{
		
		User user = (User) object;
		user.isOnline = false;
		try 
		{
			FileInputStream readUser1 = new FileInputStream("user.txt");
			@SuppressWarnings("resource")
			ObjectInputStream readUser2 = new ObjectInputStream(readUser1);
			//userReg = (ArrayList<User>) readUser2.readObject();
			userReg = (ArrayList<User>) readUser2.readObject();
			int size1 = ul.size();
			for(int i = 0; i < size1; i++)
			{
				if(ul.get(i).name.equals(user.name))
				{
					user.isOnline = true;
					break;
				}
			}
			int size = userReg.size();
			for(int i = 0; i < size; i++)
			{
				if(userReg.get(i).name.equals(user.name))
				{
					
					if(user.isOnline)
					{
						outputStream.println("用户已登录");
						break;
					}
					else if(ul.size() == maxNum)
					{
						outputStream.println("聊天室已满");
						break;
					}
					else if(userReg.get(i).getPwd().equals(user.getPwd()))
					{
						user.isOnline = true;
						user.headpic = userReg.get(i).headpic;
						ul.add(user);
						outputStream.println("成功登录");
						freshUL();
						break;
					}
					else
					{
						outputStream.println("密码错误");
						break;
					}
					
				}
			}
		} 
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void freshUL()
	{
		String[] nul = new String[maxNum];
		int size = ul.size();
		for(int i = 0; i < size; i++)
		{
			nul[i] = ul.get(i).name;
		}
		sw.userList.setListData(nul);
		sw.text_onlineUse.setText("" + size);
		
	}
	public void sendNotice()
	{
		Notice notice = (Notice) object;
		notice.userOnline = ul;
		notice.records = rl;
		notice.notice = "" + sw.systemMessage;
		try 
		{
			ObjectOutputStream ops 
			= new ObjectOutputStream(cs.getOutputStream());
			ops.writeObject(notice);
			cs.close();
			ops.close();
		} 
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void patpat()
	{
		PatRecord pr = (PatRecord) object;
		
	}
	public void sendChat()
	{
		Record record = (Record) object;
		String chat = sw.text_message.getText();
		if(record.isPrivate == false)
		{
			chat += "\n" + "[ " + record.sender + " -> " + record.receiver + " : " + record.chatComp;
			
		}
		sw.text_message.setText(chat);
		rl.add(record);
		return;
	}
	public ServerThread(ServerWindow sw, Socket cs, ArrayList<User> ul, ArrayList<Record> rl) throws IOException
	{
		this.sw = sw;
		this.cs = cs;
		this.ul = ul;
		this.rl = rl;
//		inputStream = new ObjectInputStream(this.cs.getInputStream());
	//	outputStream = new PrintStream(this.cs.getOutputStream());

	}

}
